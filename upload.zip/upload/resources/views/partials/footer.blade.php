<footer class="main-footer hidden-print">
    <div class="pull-right hidden-xs">
      <b>{{__('Version')}}</b> 5.6
    </div>
    <strong>{{__('Copyright')}} &copy; 2017-2022 <a href="http://flexibleit.net/"><img src="{{asset("images/flexibleit_logo.png")}}" alt="" class="footer-logo"></a></strong> {{__('All rights reserved.')}}
</footer>
<script>
  var site_url = "{{url('/')}}";
</script>
