@if(config('fpos.demo'))
<span class="text-center buy-now-text">It is a demo site all data will be reset at any time! <a href="https://codecanyon.net/item/flexiblepos-with-inventory-management-system/23633865" class="btn btn-sm btn-info">Buy Now</a></span>
@endif