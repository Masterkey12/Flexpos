@extends('layouts.admin_dynamic')

@section('content')
<div class="content-wrapper">
    @include('customer.customer')
</div>
@include('partials.gadds')
@endsection
