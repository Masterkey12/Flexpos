<?php

return [
    'edit' => 'Edit',
    'delete' => 'Delete',
];
