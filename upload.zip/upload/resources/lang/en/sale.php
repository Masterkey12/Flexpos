<?php

return [

	'sales_register' => 'Sales Register',
	'search_item' => 'Search Item:',
	'invoice' => 'Invoice',
	'employee' => 'Employee',
	'payment_type' => 'Payment Type',
	'customer' => 'Customer',
	'item_id' => 'Item ID',
	'item_name' => 'Item Name',
	'price' => 'Price',
	'quantity' => 'Quantity',
	'total' => 'Total',
	'add_discount_flat' => 'Add Flat Discount',
	'add_discount_percent' => 'Add Discount (%)',
	'add_tax_percent' => 'Add Tax (%)',
	'add_payment' => 'Add Payment',
	'comments' => 'Comments',
	'sub_total' => 'Sub Total:',
	'grand_total' => 'Total:',
	'grand_dues' => 'Dues:',
	'amount_discount' => 'Discount : ',
	'amount_payment' => 'Payment : ',
	'submit' => 'Complete Sale',
	'tax' => 'Tax',
	//struk
	'sale_id' => 'Sale ID',
	'item' => 'Item',
	'qty' => 'Qty',
	'print' => 'Print',
	'new_sale' => 'New Sale',
	'address' => 'Address ',
	'mobile' => 'Mobile/Phone '
];
