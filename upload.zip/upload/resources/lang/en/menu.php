<?php

return [

	'dashboard' 			=> 'Dashboard',
	'customers' 			=> 'Customers',
	'employees'				=> 'Employees',
	'barcode'				=> 'Barcode',
	'items' 				=> 'Items',
	'item_kits' 			=> 'Item Kits',
	'suppliers' 			=> 'Suppliers',
	'receivings' 			=> 'Receivings',
	'sales' 				=> 'Sales',
	'expense' 				=> 'Expense',
	'reports' 				=> 'Reports',
	'receivings_report' 	=> 'Receivings Report',
	'sales_report' 			=> 'Sales Report',
	'print_sales_report' 	=> 'Print Sales Report',
	'daily_report' 			=> 'Daily Report',
	'accounts' 			    => 'Accounts',
	'logout'				=> 'Logout',
	'application_settings' 	=> 'Application Settings'

];
