<?php

return [

    'list_employees' => 'Listado de Empleados',
    'new_employee' => 'Nuevo Empleado',
    'person_id' => 'ID',
    'name' => 'Nombre',
    'email' => 'Email',
    'password' => 'Contraseña',
    'confirm_password' => 'Confirmar Contraseña',
    'submit' => 'Guardar',
    'edit' => 'Editar',
    'delete' => 'Borrar',
    'update_employee' => 'Actualizar Empleado'
];
