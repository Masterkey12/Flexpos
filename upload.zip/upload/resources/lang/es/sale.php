<?php

return [

    'sales_register' => 'Registro de Ventas',
    'search_item' => 'Buscar Producto:',
    'invoice' => 'Recibo',
    'employee' => 'Empleado',
    'payment_type' => 'Tipo de Pago',
    'customer' => 'Cliente',
    'item_id' => 'ID',
    'item_name' => 'Producto',
    'price' => 'Precio',
    'quantity' => 'Cantidad',
    'total' => 'Total',
    'add_payment' => 'Agregar Pago',
    'comments' => 'Comentarios',
    'grand_total' => 'TOTAL:',
    'amount_due' => 'Monto a Pagar',
    'submit' => 'Completar Venta',
    //struk
    'sale_id' => 'ID',
    'item' => 'Producto',
    'price' => 'Precio',
    'qty' => 'Cantidad',
    'print' => 'Imprimir',
    'new_sale' => 'Nueva Venta',
];
