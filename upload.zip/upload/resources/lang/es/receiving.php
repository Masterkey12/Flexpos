<?php

return [

    'item_receiving' => 'Compra de Productos',
    'search_item' => 'Buscar Producto:',
    'invoice' => 'Recibo',
    'employee' => 'Empleado',
    'payment_type' => 'Tipo de Pago',
    'supplier' => 'Proveedor',
    'item_id' => 'ID',
    'item_name' => 'Producto',
    'cost' => 'Costo',
    'quantity' => 'Cantidad',
    'total' => 'Total',
    'amount_tendered' => 'Monto Recibido',
    'comments' => 'Comentarios',
    'grand_total' => 'TOTAL:',
    'submit' => 'Finalizar Compra',
    //struk
    'receiving_id' => 'Receiving ID',
    'item' => 'Producto',
    'price' => 'Precio',
    'qty' => 'Cantidad',
    'print' => 'Imprimir',
    'new_receiving' => 'Nueva Compra',
];
