$(function () {
    'use strict';
    $('.select2-container').remove();
    $('.select2').select2();
});