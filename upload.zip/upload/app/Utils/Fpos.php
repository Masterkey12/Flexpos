<?php

namespace App\Utils;

class Fpos
{
    const DEMO_URL = "https://flexiblepos.flexibleit.net";
}
